// Fast Toolkit Google Apps Script Client API
(function () {
  const Config = window.FAST_TOOLKIT_CONFIG || {};

  window.GASClient = {
    /**
     * جلب الإعدادات والقواعد الحية من Google Apps Script
     */
    async fetchRemoteConfig() {
      const url = Config.GAS_WEB_APP_URL;
      if (!url) {
        console.log("[Fast Toolkit] لم يتم تعيين رابط Google Apps Script بعد. استخدام الإعدادات المحلية.");
        return Config.LOCAL_FALLBACKS;
      }

      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), Config.REQUEST_TIMEOUT_MS || 5000);

        const response = await fetch(`${url}?action=getConfig`, {
          signal: controller.signal
        });
        clearTimeout(timeoutId);

        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        const data = await response.json();
        
        // التخزين المؤقت في chrome.storage أو localStorage
        if (data && data.status === "success") {
          localStorage.setItem("fastToolkit_cached_config", JSON.stringify(data));
          return data;
        }
      } catch (err) {
        console.warn("[Fast Toolkit] فشل الاتصال بـ Google Apps Script، الاعتماد على التخزين المؤقت:", err.message);
      }

      // إرجاع الإعدادات المخزنة مؤقتاً أو الاحتياطية
      const cached = localStorage.getItem("fastToolkit_cached_config");
      return cached ? JSON.parse(cached) : Config.LOCAL_FALLBACKS;
    },

    /**
     * إرسال بيانات أو ملاحظة للحفظ في Google Sheet عبر السكربت
     */
    async sendData(action, payload) {
      const url = Config.GAS_WEB_APP_URL;
      if (!url) {
        console.warn("[Fast Toolkit] تعذر الحفظ السحابي: رابط السكربت غير محدد.");
        return { status: "offline", message: "GAS URL not configured" };
      }

      try {
        const response = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "text/plain;charset=utf-8" },
          body: JSON.stringify({ action: action, ...payload })
        });
        return await response.json();
      } catch (err) {
        console.error("[Fast Toolkit] خطأ أثناء الحفظ في السكربت:", err);
        return { status: "error", message: err.message };
      }
    }
  };
})();
