// Central Configuration for Fast Toolkit Chrome Extension

window.FAST_TOOLKIT_CONFIG = {
  // وضع التطبيق (production / development)
  ENV: "production",
  
  // الإصدار الحالي
  VERSION: "1.2.0",
  
  // رابط Google Apps Script الخاص بك (ضع رابط Web App النهائي هنا عند نشره)
  GAS_WEB_APP_URL: "", // مثال: "https://script.google.com/macros/s/AKfycbx.../exec"
  
  // المهلة الزمنية لطلبات الـ API (بالمللي ثانية)
  REQUEST_TIMEOUT_MS: 5000,
  
  // الإعدادات المحلية الاحتياطية (تُستخدم إذا كان السكربت غير متوفر أو لم يُربط بعد)
  LOCAL_FALLBACKS: {
    announcement: "",
    features: {
      cardScanEnabled: true,
      simahEnabled: true,
      noteEnabled: true,
      ciaEnabled: true,
      dateEnabled: true,
      stickyEnabled: true
    }
  }
};
